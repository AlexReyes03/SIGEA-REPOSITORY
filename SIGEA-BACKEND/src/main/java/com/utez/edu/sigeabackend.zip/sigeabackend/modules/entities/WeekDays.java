package com.utez.edu.sigeabackend.modules.entities;

public enum WeekDays {
    LUN,
    MAR,
    MIE,
    JUE,
    VIE,
    SAB,
    DOM
}
