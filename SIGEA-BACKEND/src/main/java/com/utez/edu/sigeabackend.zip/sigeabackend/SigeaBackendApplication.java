package com.utez.edu.sigeabackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SigeaBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(SigeaBackendApplication.class, args);
    }

}
