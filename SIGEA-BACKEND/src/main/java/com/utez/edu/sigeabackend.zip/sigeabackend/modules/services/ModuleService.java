package com.utez.edu.sigeabackend.modules.services;

public class ModuleService {
}
