package com.utez.edu.sigeabackend.modules.repositories;

public interface RankingRepository {
}
