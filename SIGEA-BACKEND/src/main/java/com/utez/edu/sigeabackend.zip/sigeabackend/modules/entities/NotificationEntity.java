package com.utez.edu.sigeabackend.modules.entities;


public class NotificationEntity {
}
